import React from "react";

function NotFoundPage() {
  return <div> NotFoundPage</div>;
}

export default NotFoundPage;
